<?php
//define ("DB_HOST", "localhost"); // set database host
//define ("DB_USER", "canada-gc-ca"); // set database user
//define ("DB_PASS","WeaYsAW6Jxphgbn"); // set database password
//define ("DB_NAME","status_canada_gc_ca"); // set database name

$con = mysqli_connect(DB_HOST, DB_USER, DB_PASS) or die("Couldn't make connection.");
$db = mysqli_select_db($con, DB_NAME) or die("Couldn't select database");

function mysqli_result($res, $row, $field=0) { 
    $res->data_seek($row); 
    $datarow = $res->fetch_array(); 
    return $datarow[$field]; 
} 
function db_connect(){
global $con;
$result = $con;
if (!$result){ return false; }
if (!mysqli_select_db($con, 'immicanada')){ return false; }
return $result;
}

function record_exists($query){ 
    global $con;
	// used to check existing data
	if (!db_connect()) return false;
	if (!$query) return false;
	$result = mysqli_query($con, $query);
	if (!$result) return false;
	if (mysqli_num_rows($result)>0){ return true; }
	else{ return false; }
}

function get_record($query){
	global $con;
	// used to get data only where data sure exists or else it reurns false
	if(!db_connect()){ return false;}
	if (!$query){ return false;}
	$result = mysqli_query($con, $query);
	if(!$result){ return false; }
	if (mysqli_num_rows($result)>0){ return trim(mysqli_result($result, 0, 0)); }
	else{ return false; }
}

function formatDate($val)
// format MySQL DATETIME value into a more readable string
{
$arr = explode('-', $val);
return date('d M, Y', mktime(0,0,0, $arr[1], $arr[2], $arr[0]));
}

// function to check if current date is greater than expiry
function check_date($start_date, $end_date) {
$start = strtotime($start_date);
$end = strtotime($end_date); 
if ($start - $end > 0) {
return 1;
}
else {
return 0;
}
}
?>