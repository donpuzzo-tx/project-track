<?php
// Initialize the session
 include 'visafee.php';
 include 'vfsfunc.php';
session_start();
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../login.php");
    exit;
}
$first_name = get_record("select first_name from users where user_name = '".$_SESSION["user_name"]."' ");
$last_name = get_record("select last_name from users where user_name = '".$_SESSION["user_name"]."' ");
$gender = get_record("select gender from users where user_name = '".$_SESSION['user_name']."' ");
$date_of_birth = get_record("select date_of_birth from users where user_name = '".$_SESSION['user_name']."' ");
$address = get_record("select address from users where user_name = '".$_SESSION['user_name']."' ");
$city = get_record("select city from users where user_name = '".$_SESSION['user_name']."' ");
$state = get_record("select state from users where user_name = '".$_SESSION['user_name']."' ");
$nationality = get_record("select nationality from users where user_name = '".$_SESSION['user_name']."' ");
$email = get_record("select email from users where user_name = '".$_SESSION['user_name']."' ");
$phone = get_record("select phone from users where user_name = '".$_SESSION['user_name']."' ");
$track_no = get_record("select user_name from users where user_name = '".$_SESSION['user_name']."' ");
$visa_no = get_record("select visa_no from users where user_name = '".$_SESSION['user_name']."' ");
$pass_no = get_record("select pass_no from users where user_name = '".$_SESSION['user_name']."' ");
$visa_type = get_record("select visa_type from users where user_name = '".$_SESSION['user_name']."' ");
$visa_status = get_record("select visa_status from users where user_name = '".$_SESSION['user_name']."' ");
$vp = get_record("select validity_period from users where user_name = '".$_SESSION['user_name']."' ");
$idate = get_record("select issued_date from users where user_name = '".$_SESSION['user_name']."' ");
$xpd = get_record("select expiry_date from users where user_name = '".$_SESSION['user_name']."' ");
$passport = get_record("select passport from users where user_name = '".$_SESSION['user_name']."' ");
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome <?php echo "$first_name";?>&nbsp;<?php echo "$last_name"; ?> </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
	<script src="jquery-1.8.3.js"></script>
	<script>
	$(function() {
		$(".preload").fadeOut(2000, function() {
			$(".content").fadeIn(1000);
		});
	});
     </script> 
	
    <style type="text/css">
        .preload{ margin:0; position:absolute; top:50%; left:50%; margin-right: -50%; transform:translate(-50%, -50%);}
         body{ font: 14px sans-serif; text-align: center; background-image: url("bg.jpg"); background-repeat: no-repeat; background-size: 100% 100%; background-attachment: fixed;}
		.main-header {overflow: hidden; background-color: #f1f1f1; padding: 20px 10px; position: fixed; top: 0; width: 100%;}
        .footer {position: fixed; left: 0; bottom: 0; padding-top:10px; width: 100%; background-color: red; color: white;text-align: center;}
		.main-header a { float: left; color: black; text-align: center; padding: 12px; text-decoration: none; font-size: 18px; line-height: 25px; border-radius: 4px; }
		.main-header a.logo { font-size: 25px; font-weight: bold; }
		.logo{content:url(../../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/logos/II-logo9.png);}
        .main-header a:hover { background-color: #ddd; color: black; }
        .main-header a.active { background-color: dodgerblue; color: white; }
		.header-right { float: right; }
		.page-header {float:left; align:justify padding-top:5px;}
		.page-header-right { float: right; padding-top:5px; }
		@media screen and (max-width: 500px) {
        .main-header a { float: none; display: block; text-align: left;}
        .header-right { float: none;}
		}
		.ds_box { background-color: #FFF; border: 3px solid #000; position: absolute; z-index: 32767; }
		.ds_tbl { background-color: #FFF;}
		.ds_head { background-color: #333; color: #FFF; font-family: Arial, Helvetica, sans-serif; font-size: 15px; font-weight: bold; text-align: center; letter-spacing: 2px; }
        .ds_subhead { background-color: #CCC; color: #000; font-size: 12px; font-weight: bold; text-align: center; font-family: Arial, Helvetica, sans-serif; width: 32px; }
        .ds_cell { background-color: #EEE; color: #000; font-size: 13px; text-align: center; font-family: Arial, Helvetica, sans-serif; padding: 5px; cursor: pointer; }
        .ds_cell:hover { background-color: #F3F3F3; } 
        
    </style>
</head>
<body>
<div class="main-header">
 <a class="logo"></a>
 <div class="header-right">
    <a class="active" href="#home">Applicant Details</a>
    <a href="reset-password.php" >Reset Password</a>
    <a href="logout.php">Sign Out</a>
  </div>
</div>
</br>
<div style="padding-top: 120px;"></div>
<div>
<p>
        <a href="reset-password.php" class="btn btn-warning">Visa Related Payment Portal</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="logout.php" class="btn btn-danger">View Your Visa Application Status</a>
</p>
</div>
<div class="preload">
    	<img src="loading_spinner.gif" />
</div>
<div class="container" style="width:906px; height:600px; margin:0 auto;">
    <div class="page-header"> <h3>Welcome, <b><?php echo "$first_name";?>&nbsp;<?php echo "$last_name"; ?> &nbsp;(<?php echo htmlspecialchars($_SESSION["user_name"]); ?>)</b>. </br></br> Canadian Immigration Account System.</h3></div>
	<div class="page-header-right"><div align="center"><span class="Partext1"><img src="../pax/<?php  echo $passport; ?>" width="109" height="132" /></span></div></div>
    <table class="ds_box" id="ds_conclass" style="display: none;" cellpadding="0" cellspacing="0"> 
        
        <tbody><tr> 
          
          <td id="ds_calclass"> </td> 
    
          </tr> 
          </tbody>
      </table>
      <div align="left">
        <!--<p><span class="style4">Confirmation</span><br>
            <br>
          
            <span class="style5" id="ctl00_ContentPlaceHolder1_lblWelcome">This confirms the submission of the visa application for : <strong><?php echo "$first_name";?>&nbsp;<?php echo "$last_name"; ?></strong></span></p>-->
        <table width="874" height="319" border="1" align="center">
          <tr>
            <td bgcolor="#DDDDDD"><div align="center" dir="ltr">
              <p>&nbsp;</p>
              <table width="90" height="204" border="0" align="left" cellpadding="5" cellspacing="0" bgcolor="#F3F3F3">
                <!--<tr>
                  <td width="133" bgcolor="#FFFFFF"><div align="center"><span class="Partext1"><img src="../pax/" width="109" height="132" /></span></div></td>
                </tr>-->
              </table>
			  
              <table width="80%" height="262" align="left" cellpadding="8" cellspacing="8" bgcolor="#EEEEEE">
                <tbody>
                  <tr>
                    <td width="275" align="right" bgcolor="#FFFFFF" class="aamessage style3"><div align="left"><strong>Name Provided (As Printed on Passport) :</strong></div></td>
                    <td width="301" bgcolor="#FFFFFF" class="aamessage"><strong> <?php echo "$first_name";?>&nbsp;<?php echo "$last_name"; ?></strong></td>
                  </tr>
                  <tr>
                    <td align="right" bgcolor="#FFFFFF" class="aamessage style3"><div align="left"><strong>Date Of Birth : </strong></div></td>
                    <td class="aamessage" bgcolor="#FFFFFF"><?php echo  "$date_of_birth"; ?>&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" bgcolor="#FFFFFF" class="aamessage style3"><div align="left"><strong>Place of Birth: </strong></div></td>
                    <td class="aamessage" bgcolor="#FFFFFF"><?php echo  "$nationality"; ?>&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" bgcolor="#FFFFFF" class="aamessage style3"><div align="left"><strong>Gender   : </strong></div></td>
                    <td class="aamessage" bgcolor="#FFFFFF"><?php echo  "$gender"; ?></td>
                  </tr>
                  <tr>
                    <td align="right" bgcolor="#F3F3F3" class="aamessage style3"><div align="left"><strong>Nationality   :</strong></div></td>
                    <td class="style3" bgcolor="#F3F3F3"><span class="aamessage"><?php echo  "$nationality"; ?></span></td>
                  </tr>
                  <tr>
                    <td align="right" bgcolor="#FFFFFF" class="aamessage style3"><div align="left">Address :</div></td>
                    <td class="aamessage" bgcolor="#FFFFFF"><?php echo  "$address"; ?></td>
                  </tr>
                  <tr>
                    <td align="right" valign="top" bgcolor="#FFFFFF" class="aamessage style3"><div align="left"><strong>Passport No : </strong></div></td>
                    <td class="aamessage" bgcolor="#FFFFFF"><?php echo  "$pass_no"; ?></td>
                  </tr>
                  <tr>
                    <td height="22" align="right" valign="top" bgcolor="#FFFFFF" class="aamessage style3"><div align="left"><strong>Visa Type: </strong></div></td>
                    <td class="aamessage" bgcolor="#FFFFFF"><?php echo  "$visa_type"; ?></td>
                  </tr>
                  <tr>
                    <td height="22" align="right" valign="top" bgcolor="#F3F3F3" class="aamessage style3"><div align="left"><strong>Applied Date </strong>:</div></td>
                    <td class="aamessage" bgcolor="#F3F3F3"><?php echo  "$idate"; ?></td>
                  </tr>
                  <!--<tr>
                    <td height="22" align="right" valign="top" bgcolor="#F3F3F3" class="aamessage style3"><div align="left"><strong>Visa Status </strong>:</div></td>
                    <td class="aamessage" bgcolor="#F3F3F3"><?php echo  "$visa_status"; ?></td>
                  </tr>-->
                   <tr>
                    <td height="22" align="right" valign="top" bgcolor="#F3F3F3" class="aamessage style3"><div align="left"><strong>Confirmation No </strong>:</div></td>
                    <td class="aamessage" bgcolor="#F3F3F3"><?php echo  "$track_no"; ?></td>
                  </tr>
				  </td>
                </tbody>
              </table>
           
</div>
</br>
</br>
</br>
<div class="footer">
    <p> Canada Immigration Services All rights Reserved 2019 © </p>
</div>
</div>
</body>
</html>