<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: ./sys/welcome.php");
  exit;
}
 
// Include config file
require_once "./sys/config.php";
 
// Define variables and initialize with empty values
$user_name = $password = "";
$username_err = $password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if user_name is empty
    if(empty(trim($_POST["user_name"]))){
        $username_err = "Please enter username.";
    } else{
        $user_name = trim($_POST["user_name"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, user_name, password FROM user_login WHERE user_name = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $user_name;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if user_name exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $user_name, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["user_name"] = $user_name;                            
                            
                            // Redirect user to welcome page
                            header("location: ./sys/welcome.php");
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else{
                    // Display an error message if user_name doesn't exist
                    $username_err = "No account found with that username.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from www.canadaimmigration.services/Account/Login by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 Aug 2019 09:25:38 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-111748542-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag() { dataLayer.push(arguments); }
            gtag('js', new Date());

            gtag('config', 'UA-111748542-1');
        </script>

        <title>Client Login</title>
        <meta name="description" content="SSL Secure Client Login area for application and immigration process.">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta property="og:title" content="Client Login" />
        <meta property="og:description" content="SSL Secure Client Login area for application and immigration process." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.immicanada.international/Account/Login" />
        <meta property="og:image" content="//investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/logos/II-logo9.png" />
        <meta property="og:image:secure_url" content="https://investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/logos/II-logo9.png" />
        <meta property="og:image:type" content="image/png" />

        <meta name="p:domain_verify" content="768abcca23654e9a82e6571fd9d16fd3" />

        <link rel="icon" type="image/x-icon" href="http://investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/icons/favicon.ico" />
        <link rel="shortcut icon" href="http://investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/icons/favicon.ico" />

        <link rel="alternate" href="Login.php" hreflang="en" />
        <link rel="alternate" href="Login.php" hreflang="x-default" />
        <link rel="canonical" href="Login.php" />

        <script type="application/ld+json">
            {
            "@context" : "http://schema.org",
            "@type" : "LocalBusiness",
            "name" : "Canadian Immigration & Citizenship Services in Vancouver",
            "image" : "https://investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/650/Vancouver-skyline-aerial.jpg",
            "telephone" : "+1-604-440-0753",
            "email" : "info@immicanada.international",
            "address" : {
            "@type" : "PostalAddress",
            "streetAddress" : "701 W Georgia St #1500",
            "addressLocality" : "Vancouver",
            "addressRegion" : "BC",
            "addressCountry" : "Canada",
            "postalCode" : "V7Y1C6"
            },
            "url" : "https://www.immicanada.international"
            }
        </script>
		

        <script src="../../ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <script src="../Scripts/jquery.smartmenus.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
        <link href="../Content/css5a0d.css?v=IXww97S4jjNWL0NDKd6rx7FdwALaodAbie9kWcKcdWk1" rel="stylesheet"/>
        <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
        </style>
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>

    <body>
        <!-- Google Tag Manager (noscript) -->
        <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P2RWPMG"
                    height="0" width="0" style="display:none;visibility:hidden"></iframe>
        </noscript>
        <!-- End Google Tag Manager (noscript) -->
        <div class="container-fluid upper-header">
            <div class="row">
                <div class="col-xs-12 padding-rl-0">
                    <div class="upper-header-address pull-left tablet-hide">
                        701 W Georgia St #1500, Vancouver, BC V7Y1C6, Canada
                    </div>
                    <div class="top-header-item hide-1024">
                        <a href="#">
                            <div id="google_translate_element"></div>
                        </a>
                    </div>
                    <div class="top-header-item">
                        <a href="../News/Latest.html">
                            <span class="glyphicon glyphicon-globe"></span> News
                        </a>
                    </div>
                        <div class="top-header-item">
        <a href="Login.php"><span class="glyphicon glyphicon-cog"></span> Client Login</a>
    </div>

                </div>
            </div>
        </div>

        <nav class="navbar navbar-default">
            <div class="row">
                <div class="col-xs-12 padding-0">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="../index.html">
                            <img alt="InvestImmi Logo" src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/logos/II-logo9.png" />
                        </a>
                    </div>

                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        


    <ul  id="main-menu" class="sm sm-simple">
                <li><a href="../Home/WhyCanada.html" target="">Why Canada</a></li>
                <li>
                    <a>
                        Permanent&nbsp;<span class="caret"></span>
                    </a>
                        <ul>
                <li>
                    <a href="#">
                        Business&nbsp;<span class="caret-right"></span>
                    </a>
                        <ul>
                <li><a href="../Business/IIVC.html">Federal Investor Program</a></li>
                <li><a href="../Business/QuebecInvestor.html">Investor and Business Programs in Quebec</a></li>
                <li><a href="../Business/ProvincialInvestment.html">Provincial Investment and Business Program</a></li>
                <li><a href="../Business/StartUpVisa.html">Start-up Visa</a></li>
                <li><a href="../Business/SelfEmployed.html">Self-Employed Persons Program</a></li>
    </ul>

                </li>
                <li>
                    <a href="#">
                        Professional&nbsp;<span class="caret-right"></span>
                    </a>
                        <ul>
                <li><a href="../SkilledWorker/ExpressEntry.html">Express Entry</a></li>
                <li><a href="../SkilledWorker/FederalSkilledWorker.html">Federal Skilled Worker Program</a></li>
                <li><a href="../SkilledWorker/FederalSkilledTrade.html">Federal Skilled Trade Program</a></li>
                <li><a href="../SkilledWorker/CanadianExpirienceClass.html">Canadian Experience Class Program</a></li>
    </ul>

                </li>
    </ul>

                </li>
                <li>
                    <a>
                        Temporary&nbsp;<span class="caret"></span>
                    </a>
                        <ul>
                <li>
                    <a href="#">
                        Work&nbsp;<span class="caret-right"></span>
                    </a>
                        <ul>
                <li><a href="../JobsInCanada.html">Canada Job Search</a></li>
                <li><a href="../Worker/TemporaryWorker.html">Temporary Foreign Worker</a></li>
                <li><a href="../Worker/Caregivers.html">Live-in Caregivers</a></li>
                <li><a href="../Worker/Employers.html">Employer Services</a></li>
                <li><a href="../Worker/IEC.html">International Experience Canada</a></li>
    </ul>

                </li>
                <li>
                    <a href="#">
                        Study&nbsp;<span class="caret-right"></span>
                    </a>
                        <ul>
                <li><a href="../Study/index.html">Why study in Canada?</a></li>
                <li><a href="../Study/Services.html">Our Services for Students</a></li>
    </ul>

                </li>
                <li>
                    <a href="#">
                        Business&nbsp;<span class="caret-right"></span>
                    </a>
                        <ul>
                <li><a href="../BusinessVisa/BusinessVisitor.html">Business Visitor</a></li>
                <li><a href="../BusinessVisa/IntraCompanyTransferee.html">Intra-Company Transferee</a></li>
                <li><a href="../BusinessVisa/NAFTABusinessVisitors.html">NAFTA</a></li>
    </ul>

                </li>
                <li>
                    <a href="#">
                        Visit&nbsp;<span class="caret-right"></span>
                    </a>
                        <ul>
                <li><a href="../Visit/CanadianVisaOnline.html">Visit Visa</a></li>
                <li><a href="../Visit/SuperVisa.html">Parent and Grandparent Super Visa</a></li>
    </ul>

                </li>
    </ul>

                </li>
                <li>
                    <a>
                        Sponsorship&nbsp;<span class="caret"></span>
                    </a>
                        <ul>
                <li><a href="../FamilySponsorship/SpousalSponsorship.html">Spousal Sponsorship</a></li>
                <li><a href="../FamilySponsorship/ParentsAndGrandparentsSponsorship.html">Parents and Grandparents Sponsorship</a></li>
                <li><a href="../FamilySponsorship/SameSexSponsorship.html">Same Sex Partners Sponsorship</a></li>
    </ul>

                </li>
                <li>
                    <a>
                        Appeals&nbsp;<span class="caret"></span>
                    </a>
                        <ul>
                <li><a href="../ImmigrationAppeals/SponsorshipAppeals.html">Sponsorship Appeal Process</a></li>
                <li><a href="../ImmigrationAppeals/RemovalOrderAppeals.html">Removal Order Appeals</a></li>
                <li><a href="../ImmigrationAppeals/ResidencyObligationAppeals.html">Residency Obligation Appeals</a></li>
    </ul>

                </li>
                <li>
                    <a>
                        Services&nbsp;<span class="caret"></span>
                    </a>
                        <ul>
                <li><a href="../Consultation/Create.html">Consultation</a></li>
                <li><a href="../Services/Qualification.html">Qualification</a></li>
                <li><a href="../JobsInCanada.html">Jobs in Canada</a></li>
    </ul>

                </li>
                <li>
                    <a>
                        About&nbsp;<span class="caret"></span>
                    </a>
                        <ul>
                <li><a href="../Home/About.html">About Us</a></li>
                <li><a href="../Home/ChooseRightImmigrationRepresentative.html">About Immigration Representatives</a></li>
    </ul>

                </li>
                <li><a href="../Home/Contact.html" target="">Contact</a></li>
    </ul>

                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            
<div class="container margin-tb-40">
    <div class="row">
        <div class="col-xs-12">
            <h1>Secured Client Login</h1>
            <br />

            <div class="row">
                <div class="col-md-6">
                    <img src="../../s3-us-west-2.amazonaws.com/investimmi-cdn/Content/img/small/secured-login.jpg" class="img-responsive img-rounded" alt="Secured Client Login" title="Secured Client Login" />
                </div>

                <div class="col-md-6 margin-top-40">
				<div class="wrapper">
      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="form-horizontal" method="post" ><div class="form-group">
                          
					    <label for="Email">Username</label>
                        <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                                <input class="form-control" name="user_name" type="text" value="<?php echo $user_name; ?>" />
                                <span class="help-block"><?php echo $username_err; ?></span>
							 
                        </div>
						</div>  
                        <div class="form-group">
                            <label for="Password">Password</label>
                            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                                <input autocomplete="off" class="form-control" name="password" type="password" />
                                <span class="help-block"><?php echo $password_err; ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <div class="checkbox">
                                    <input data-val="true" data-val-required="The Remember me field is required." id="RememberMe" name="RememberMe" type="checkbox" value="true" /><input name="RememberMe" type="hidden" value="false" />
                                    <label for="RememberMe">Remember me</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <a href="./sys/reset-password.php">Forgot your password?</a>
                            </div>
                        </div>
                        <div class="form-group">
                            
                                <input type="submit" value="Login" class="btn btn-primary" />
                           
                        </div>
						</div>
</form>                </div>

            </div>
        </div>

        

    </div>
</div>
        </div>

        <div id="footer">
            <div class="footer-menu">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3">
                            <h4>Canada Immigration</h4>
                            <ul>
                                <li><a href="../Business/IIVC.html">Business/Investor</a></li>
                                <li><a href="../SkilledWorker/ExpressEntry.html">Skilled Professional</a></li>
                                <li><a href="../Worker/TemporaryWorker.html">Temporary Work</a></li>
                                <li><a href="../Study.html">Study in Canada</a></li>
                                <li><a href="../Visit/CanadianVisaOnline.html">Visit Canada</a></li>
                                <li><a href="../News/Latest.html">News</a></li>
                            </ul>
                        </div>
                        <div class="col-sm-3">
                            <h4>Our Services</h4>
                            <ul>
                                <li><a href="../Consultation/Create.html">Consultation</a></li>
                                <li><a href="BusinessAIAFIntro.html">Business Qualification</a></li>
                                <li><a href="AIAFIntro.html">Professional Qualification</a></li>
                                <li><a href="StudentAIAFIntro.html">Student Permit Qualification</a></li>
                                <li><a href="../JobsInCanada.html">Jobs in Canada</a></li>
                            </ul>
                        </div>
                        <div class="col-sm-3">
                            <h4>About Us</h4>
                            <ul>
                                <li><a href="../Home/About.html">Who we are</a></li>
                                <li><a href="../Home/Contact.html">Contact Us</a></li>
                                <li><a href="../Home/Privacy.html">Privacy Policy</a></li>
                                <li><a href="../Home/Refund.html">Refund Policy</a></li>
                            </ul>
                        </div>
                        <div class="col-sm-3">
                            <h4>Social</h4>
                            <p class="social-links">
                                <a href="https://twitter.com/investimmi" target="_blank">
                                    <img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/icons/social/twitter-page.png" class="img-responsive" alt="Twitter page" title="Twitter page" />
                                </a>
                                <a href="https://www.facebook.com/investimmi" target="_blank">
                                    <img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/icons/social/facebook-page.png" class="img-responsive" alt="facebook page" title="facebook page" />
                                </a>
                                <a href="https://plus.google.com/+InvestimmiCa" target="_blank">
                                    <img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/icons/social/googleplus-page.png" class="img-responsive" alt="Google Plus page" title="Google Plus page" />
                                </a>
                                <a href="https://www.linkedin.com/company/nvu-investment-and-immigration-group" target="_blank">
                                    <img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/icons/social/linkedin-page.png" class="img-responsive" alt="linkedin page" title="linkedin page" />
                                </a>
                                <a href="https://youtube.com/+InvestimmiCa" target="_blank">
                                    <img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/icons/social/youtube-page.png" class="img-responsive" alt="YouTube page" title="YouTube page" />
                                </a>
                                <a href="https://www.pinterest.com/investimmi" target="_blank">
                                    <img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/icons/social/pinterest-page.png" class="img-responsive" alt="Pinterest page" title="Pinterest page" />
                                </a>
                            </p>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 text-center footer-logos">
                            <a href="http://www.imeda.ca/" target="_blank"><img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/logos/imeda-68.png" class="img-responsive" alt="IMEDA Logo" title="Member of IMEDA Alliance" /></a>
                            <a href="http://iccrc-crcic.ca/" target="_blank"><img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/logos/iccrc-logo2.png" class="img-responsive" alt="ICCRC CRCIC Logo" title="Member of ICCRC CRCIC" /></a>
                            <a href="http://www.ashtoncollege.ca/department/cpd-seminars" target="_blank"><img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/logos/cpd-logo.png" class="img-responsive" alt="CPD Logo" title="Member of Continuing Professional Development" /></a>
                            <a href="http://ucica.ca/Sys/PublicProfile/31241988" target="_blank"><img src="../../investimmi-cdn.s3-us-west-2.amazonaws.com/Content/img/logos/ucica-logo.png" class="img-responsive" alt="UCICA Logo" title="Member of United Citizenship and Immigration Consultants Association" /></a>
                            
                            
                            <span id="siteseal"></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-copyright">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="text-center">
                                &copy; Copyright 2015 - 2019 &ndash; NVU Investment and Immigration Group &reg;
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>       

        <script src="../bundles/main3df4?v=QBHlxJufG6q6dmW2HmjflkitUbXOz766usnuWC48PG41"></script>

        
        <script type="text/javascript" src="../../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>
                <script type="text/javascript" src="../../s7.addthis.com/js/300/addthis_widget.html#pubid=ra-56f9fda2b5aa2842"></script>
        <script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=8jw2gUxlxzOqp38ZRJh5wzuRMVyMAkrSlw3DiYEXdC6AN6fYBlUIluLzlR1V"></script>
    </body>

<!-- Mirrored from www.canadaimmigration.services/Account/Login by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 Aug 2019 09:25:42 GMT -->
</html>